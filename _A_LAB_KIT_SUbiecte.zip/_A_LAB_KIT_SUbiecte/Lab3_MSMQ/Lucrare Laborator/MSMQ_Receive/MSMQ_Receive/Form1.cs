﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Messaging;
using Customer1;

namespace MSMQ_Receive
{
    public partial class Form1 : Form
    {
        static int messageNumber = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            MessageQueue mq;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }
            Type[] expectedTypes = new Type[] { typeof(string), typeof(float) };
            // Construct formatter with expected types
            mq.Formatter = new XmlMessageFormatter(expectedTypes);
            // Loop forever reading messages from the queue
           // do
           // {
                 System.Messaging.Message msg = mq.Receive(); // <-- blocks until message arrives
                this.textBox1.Text = this.textBox1.Text + " "+ msg.Body.ToString();
                this.textBox1.Update();
           // }
          //  while (true);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            MessageQueue mq;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }
            Type[] expectedTypes = new Type[] { typeof(string), typeof(float) };
            // Construct formatter with expected types
            mq.Formatter = new XmlMessageFormatter(expectedTypes);
            mq.BeginReceive(TimeSpan.FromSeconds(10.0), messageNumber++,
            new AsyncCallback(MyReceiveCompleted));

        }
        private void MyReceiveCompleted(IAsyncResult asyncResult)
        {
            // Connect to the queue.
            MessageQueue queue = new MessageQueue(@".\private$\MyPrivateQ");

            // End the asynchronous receive operation.
            System.Messaging.Message msg = queue.EndReceive(asyncResult);
            this.textBox1.Text = this.textBox1.Text+ msg.Body.ToString() ;
            this.textBox1.Update();
            
        }
        private  void SetText(string text)
        {
            
                this.textBox1.Text = text;
            this.textBox1.Update();

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageQueue mq;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }
          
            mq.Formatter = new BinaryMessageFormatter();
            mq.BeginReceive(TimeSpan.FromSeconds(10.0), messageNumber++,
            new AsyncCallback(MyReceiveCompletedBinary));
        }

        private void MyReceiveCompletedBinary(IAsyncResult asyncResult)
        {
            // Connect to the queue.
            MessageQueue queue = new MessageQueue(@".\private$\MyPrivateQ");

            // End the asynchronous receive operation.
            System.Messaging.Message msg = queue.EndReceive(asyncResult);
            Customer cust = (Customer)msg.Body;
            this.textBox1.Text = this.textBox1.Text + cust.Name + " " + cust.Email + " ";
            this.textBox1.Update();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageQueue mq;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }

            mq.ReceiveCompleted += new ReceiveCompletedEventHandler(MyReceiveCompleted);


            mq.Formatter = new BinaryMessageFormatter();
            mq.BeginReceive(TimeSpan.FromSeconds(10.0));
        }
        private void MyReceiveCompleted(Object source,
        ReceiveCompletedEventArgs asyncResult)
        {
            // Connect to the queue.
            MessageQueue queue = (MessageQueue)source;

            // End the asynchronous receive operation.
            System.Messaging .Message msg = queue.EndReceive(asyncResult.AsyncResult);
      
            Customer cust = (Customer)msg.Body;
            this.textBox1.Text = this.textBox1.Text + cust.Name + " " + cust.Email + " ";
            this.textBox1.Update();

        }


    }
}
