﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Messaging;

using System.Xml;

namespace MSMQ
{
    public partial class Form1 : Form
    {
        String guid;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {

            UpdateText();
         
            MessageQueue mq = new MessageQueue(@".\private$\MyPrivateQ");
  
        }
        private void UpdateText()
        {
            System.Messaging.Message message1;
            MessageQueue mq = new MessageQueue(@".\private$\MyPrivateQ");
            System.Messaging.Message msg = new System.Messaging.Message();
            msg.Label = "A Customer object";
            Type[] expectedTypes = new Type[] { typeof(string), typeof(float) };
            // Construct formatter with expected types
            mq.Formatter = new XmlMessageFormatter(expectedTypes);
            List<System.Messaging.Message> msgList = new List<System.Messaging.Message>();
            using (MessageEnumerator me = mq.GetMessageEnumerator2())
            {
                while (me.MoveNext(new TimeSpan(0, 0, 0)))
                {
                    System.Messaging.Message message = me.Current;
                    if (message.Label == "Mesaj Editat")
                    {
                        //msgList.Add(message);
                        guid = message.Id;
                        message1 = mq.PeekById(guid);
                        this.textBox2.Text = message1.Body.ToString();
                    }
                }
            }
        }


        private void MyReceiveCompleted(IAsyncResult asyncResult)
        {
            // Connect to the queue.
            MessageQueue queue;
            Type[] expectedTypes = new Type[] { typeof(string), typeof(float) };
           
            queue = (MessageQueue)asyncResult.AsyncState;
            queue.Formatter = new XmlMessageFormatter(expectedTypes);
            System.Messaging.Message msg = queue.EndPeek(asyncResult);
            UpdateText();
            queue.BeginPeek(TimeSpan.FromDays(1),queue, new AsyncCallback(MyReceiveCompleted));
         }
        
        private void Find_Last_Message()
        {
           
            MessageQueue mq = new MessageQueue(@".\private$\MyPrivateQ");
            System.Messaging.Message msg = new System.Messaging.Message();
            Type[] expectedTypes = new Type[] { typeof(string), typeof(float) };
            // Construct formatter with expected types
            mq.Formatter = new XmlMessageFormatter(expectedTypes);
            using (MessageEnumerator me = mq.GetMessageEnumerator2())
            {
                while (me.MoveNext(new TimeSpan(0, 0, 0)))
                {
                    System.Messaging.Message message = me.Current;
                    if (message.Label == "Mesaj Editat")
                    {
                        guid = message.Id;
                      }
                }
            }
        }
        private void button8_Click(object sender, EventArgs e)
        {
            modify_text();
        }
        private void modify_text()
        {
            if (guid == null)
            {
                Init_Message();
                Find_Last_Message();
            }
                
            MessageQueue mq;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }
            Type[] expectedTypes = new Type[] { typeof(string), typeof(float) };
            // Construct formatter with expected types
            mq.Formatter = new XmlMessageFormatter(expectedTypes);
            mq.ReceiveById(guid);
            mq.Send(this.textBox2.Text, "Mesaj Editat");
        }

        private void textBox2_KeyUp(object sender, KeyEventArgs e)
        {
            Find_Last_Message();
            modify_text();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int cursor;
            cursor = this.textBox2.SelectionStart;
            UpdateText();
            this.textBox2.SelectionStart = cursor;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Init_Message();
        }
        private void Init_Message()
        {
            MessageQueue mq;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }
            System.Messaging.Message msg = new System.Messaging.Message();
            msg.Label = "Mesaj Editat";
            msg.Body = "The Message body";
            msg.UseDeadLetterQueue = true;
            mq.Send(msg);
        }
    }
}
