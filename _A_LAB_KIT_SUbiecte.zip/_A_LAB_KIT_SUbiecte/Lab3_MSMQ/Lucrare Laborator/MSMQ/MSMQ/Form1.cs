﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Messaging;
using Customer1;
using System.Xml;

namespace MSMQ
{
    public partial class Form1 : Form
    {
        String guid;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
             MessageQueue mq;
            // Does the queue already exist?
            if (MessageQueue.Exists(@".\private$\NewPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\NewPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\NewPrivateQ");
            }
            // Now use queue to send messages ...
            // Close and delete the queue
            mq.Send("The body of the message", "A message label");
            mq.Close();
           // MessageQueue.Delete(@".\private$\NewPrivateQ");
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageQueue mq;
            // Does the queue already exist?
            if (MessageQueue.Exists(@".\NewPublicQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\NewPublicQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\NewPublicQ");
            }
            // Now use queue to send messages ...
            // Close and delete the queue
            mq.Close();
          //  MessageQueue.Delete(@".\NewPublicQ");
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageQueue mq;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }
         
            System.Messaging .Message msg = new System.Messaging .Message();
            msg.Label = "A Message label";
            msg.Body = "The Message body";
            // This message waits on the queue for a max of 20 seconds.
            msg.TimeToBeReceived = TimeSpan.FromSeconds(20);
            // If the message times out, delete it from destination queue and
            // add and entry to the dead letter queue.
            msg.UseDeadLetterQueue = true;
            mq.Send(msg);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageQueue mq;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }

           
            mq.Send(this.textBox1.Text,"Label Message 1");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Create the queue instance
            MessageQueue mq = new MessageQueue(@".\private$\MyPrivateQ");
            System.Messaging.Message msg = new System.Messaging.Message();
            msg.Label = "A Customer object";
            msg.Formatter = new BinaryMessageFormatter();
            
                // Construct Customer and send to queue
                msg.Body = new Customer("Homer", "hsimpson@atomic.com", "333-33-3333");
                mq.Send(msg);
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
            System.Messaging.Message message1;
            MessageQueue mq = new MessageQueue(@".\private$\MyPrivateQ");
            System.Messaging.Message msg = new System.Messaging.Message();
            msg.Label = "A Customer object";
            Type[] expectedTypes = new Type[] { typeof(string), typeof(float) };
            // Construct formatter with expected types
            mq.Formatter = new XmlMessageFormatter(expectedTypes);
            List<System.Messaging.Message> msgList = new List<System.Messaging.Message>();

            using (MessageEnumerator me = mq.GetMessageEnumerator2())
            {
                while (me.MoveNext(new TimeSpan(0, 0, 0)))
                {
                    System.Messaging.Message message = me.Current;
                    if (message.Label =="Mesaj Editat")
                    {
                       
                        //msgList.Add(message);
                        guid = message.Id;
                        message1 = mq.PeekById(guid);
                        this.textBox2.Text = message1.Body.ToString();

                    }
                     
                }
            }
            mq.BeginReceive(TimeSpan.FromDays(1),mq,new AsyncCallback(MyReceiveCompleted));

        }

        private void MyReceiveCompleted(IAsyncResult asyncResult)
        {
            // Connect to the queue.
            MessageQueue queue;//= new MessageQueue(@".\private$\MyPrivateQ");

            // End the asynchronous receive operation.
            queue = (MessageQueue)asyncResult.AsyncState;
            System.Messaging.Message msg = queue.EndReceive(asyncResult);
            if (msg.Label == "Mesaj Editat")
            {
                this.textBox2.Text =  msg.Body.ToString();
                this.textBox2.Update();
                queue.BeginReceive(TimeSpan.FromDays(1), 0, new AsyncCallback(MyReceiveCompleted));
            }
        }
        private void button7_Click(object sender, EventArgs e)
        {
            MessageQueue mq;
           
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }

            System.Messaging.Message msg = new System.Messaging.Message();
            msg.Label = "Mesaj Editat";
            msg.Body = "The Message body";
          
           // msg.TimeToBeReceived = TimeSpan.FromSeconds(20);
           
            msg.UseDeadLetterQueue = true;
            mq.Send(msg);
        }
        private void Find_Message()
        {
            System.Messaging.Message message1;
            MessageQueue mq = new MessageQueue(@".\private$\MyPrivateQ");
            System.Messaging.Message msg = new System.Messaging.Message();
            msg.Label = "A Customer object";
            Type[] expectedTypes = new Type[] { typeof(string), typeof(float) };
            // Construct formatter with expected types
            mq.Formatter = new XmlMessageFormatter(expectedTypes);
            List<System.Messaging.Message> msgList = new List<System.Messaging.Message>();

            using (MessageEnumerator me = mq.GetMessageEnumerator2())
            {
                while (me.MoveNext(new TimeSpan(0, 0, 0)))
                {
                    System.Messaging.Message message = me.Current;
                    if (message.Label == "Mesaj Editat")
                    {
                        guid = message.Id;
                      }

                }
            }
        }
        private void button8_Click(object sender, EventArgs e)
        {
            modify_text();
        }
        private void modify_text()
        {
            MessageQueue mq;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }
            Type[] expectedTypes = new Type[] { typeof(string), typeof(float) };
            // Construct formatter with expected types
            mq.Formatter = new XmlMessageFormatter(expectedTypes);
            mq.ReceiveById(guid);
            mq.Send(this.textBox2.Text, "Mesaj Editat");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox2_KeyUp(object sender, KeyEventArgs e)
        {
            Find_Message();
            modify_text();
        }
    }
}
