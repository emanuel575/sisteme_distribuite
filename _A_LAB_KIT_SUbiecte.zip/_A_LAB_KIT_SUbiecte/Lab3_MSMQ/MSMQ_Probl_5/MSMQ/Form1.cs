﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Messaging;
using Customer1;
using System.Xml;

namespace MSMQ
{
    public partial class Form1 : Form
    {
        String guid;
        MessageQueue mq;
        Int16 MessageCounter = 0;
        string[,] studenti =new string[,] {{"Ionescu","Radu","3105"},{"Popescu","Adina","3105"},{"Caraiman","Elena","3106"}};
      
      
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

            
        private void timer1_Tick(object sender, EventArgs e)
        {
            MessageCounter++;
            if (MessageCounter > 2)
                MessageCounter = 0;
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }
            System.Messaging.Message msg = new System.Messaging.Message();
          
            msg.Formatter = new BinaryMessageFormatter();
            msg.Label = " Student " + ((MessageCounter + 1).ToString());
         
            msg.Body = new Student(studenti[MessageCounter, 0], studenti[MessageCounter, 1], studenti[MessageCounter, 2]);
            mq.Send(msg);
        }
    }
}
