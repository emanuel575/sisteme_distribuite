﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer1
{
   
    [Serializable]
    public class Student
    {
        public string mNume; // Public field
        public string mPrenume; // Private field
        public string mGrupa; // Private field with public property
       
        public Student(string nume, string prenume, string grupa)
        { mNume = nume; mPrenume = prenume; mGrupa = grupa; }
        // Required for serialization
        public Student() { }
    }
}
