﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Messaging;
using Customer1;

namespace MSMQ_Receive
{
    public partial class Form1 : Form
    {
        static int messageNumber = 0;
        MessageQueue mq;

        public Form1()
        {
            InitializeComponent();
        }
 
      
        ////////////////////////////////////////////////////////////////////////////
        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
        }
      
        private void button3_Click(object sender, EventArgs e)
        {
           
            if (MessageQueue.Exists(@".\private$\MyPrivateQ"))
            { // Yes, then create an object representing the queue
                mq = new MessageQueue(@".\private$\MyPrivateQ");
            }
            else
            { // No, create the queue and cache the returned object
                mq = MessageQueue.Create(@".\private$\MyPrivateQ");
            }
          
            mq.Formatter = new BinaryMessageFormatter();
          
            mq.BeginReceive(TimeSpan.FromSeconds(10.0), messageNumber++, new AsyncCallback(MyReceiveCompletedBinary));
           
        }

        private void MyReceiveCompletedBinary(IAsyncResult asyncResult)
        {
            // Connect to the queue.
            MessageQueue queue = new MessageQueue(@".\private$\MyPrivateQ");
          
            // End the asynchronous receive operation.
            System.Messaging.Message msg = queue.EndReceive(asyncResult);
            Student cust = (Student)msg.Body;
          
            this.textBox1.Text = this.textBox1.Text + cust.mNume+ " "+ cust.mPrenume + " "+cust.mGrupa+" " ;
            this.textBox1.Update();
            mq.BeginReceive(TimeSpan.FromSeconds(10.0), messageNumber++, new AsyncCallback(MyReceiveCompletedBinary));
        }

       


    }
}
