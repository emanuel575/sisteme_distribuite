﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace Project5XML
{
    public partial class Form1 : Form
    {
        private XmlTextWriter xr;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //   exportToXml2(this.treeView1, @"C:\TEST\Treexml.xml");
            string path = Application.StartupPath + @"\Treexml.xml";
            exportToXml2(this.treeView1, path );
            MessageBox.Show("TreeView was saved ");
        }

        public void exportToXml2(TreeView tv, string filename)
        {
            xr = new XmlTextWriter(filename, System.Text.Encoding.UTF8);
            xr.Formatting = Formatting.Indented;
            xr.Indentation = 4;
            xr.WriteStartDocument();
                xr.WriteStartElement(treeView1.Nodes[0].Text);
                foreach (TreeNode node in tv.Nodes)
                {
                    saveNode2(node.Nodes);
                }
            xr.WriteEndElement();
            xr.Close();
        }

        private void saveNode2(TreeNodeCollection tnc)
        {
            foreach (TreeNode node in tnc)
            {
                //If we have child nodes, we'll write 
                //a parent node, then iterrate through
                //the children
                if (node.Nodes.Count > 0)
                {
                    xr.WriteStartElement(node.Text);
                    xr.WriteAttributeString("Checked", node.Checked.ToString());
                    saveNode2(node.Nodes);
                    xr.WriteEndElement();
                }
                else //No child nodes, so we just write the text
                {
                    xr.WriteStartElement(node.Text);
                    xr.WriteAttributeString("Checked", node.Checked.ToString() );
                    xr.WriteString(node.Text);
                    xr.WriteEndElement();
                }
            }
        }

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    this.folderBrowserDialog1.ShowDialog()
        //}
    }
}
