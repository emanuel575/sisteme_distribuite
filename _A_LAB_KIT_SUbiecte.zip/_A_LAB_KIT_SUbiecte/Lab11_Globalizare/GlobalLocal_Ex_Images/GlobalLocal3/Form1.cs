﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Globalization;
using System.Resources;

namespace GlobalLocal3
{
    public partial class Form1 : Form
    {
        public String message1;
        public byte bx = 0;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ChangeLook();
           
        }
        private void ChangeLook()
        {
            this.Text = Resource1.Titlu;
          
            this.button1.Text = Resource1.NumeButton ;
            message1 = Resource1.Mesaj;
            this.pictureBox1.Image = Resource1.map;
            this.Icon  = Resource1.icon ;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            bx++;
            if (bx > 2)
                bx = 0;
            switch (bx)
            {
                case 0:
                    Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-GB");
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-GB");
                    ChangeLook();
                    break;
                case 1:
                    Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("fr-FR");
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("fr-FR");
                    ChangeLook();
                    break;
                case 2:
                    Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ro-RO");
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("ro-RO");
                    ChangeLook();
                    break;
                default:
                    Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ro-RO");
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("ro-RO");
                    ChangeLook();
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Resource1.Mesaj);
        }
    }
}
