﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;
using System.Threading;

namespace GlobalLocal1
{
    public partial class Form1 : Form
    {
        public String message1;
        public byte bx=0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(message1);
        }
        private void ChangeText()
        {
            this.Text = Resource1.Titlu;
            this.button1.Text = Resource1.NumeButon;
           message1 = Resource1.Mesaj;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ChangeText();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            bx++;
            if (bx > 2)
                bx = 0;
            switch (bx)
            {
                case 0:
                    Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-GB");
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("en-GB");
                    ChangeText();
                    break;
                case 1:
                    Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("fr-FR");
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("fr-FR");
                    ChangeText();
                    break;
                case 2:
                    Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ro-RO");
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("ro-RO");
                    ChangeText();
                    break;
                default:
                    Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("ro-RO");
                    Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo("ro-RO");
                    ChangeText();
                    break;
            }
                

        }
    }
}
