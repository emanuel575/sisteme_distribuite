﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;


namespace ThreadAsync
{
    public class Test
    {
        delegate int TestDelegate(string parameter);
        static void Main()
        {
            TestDelegate d = new TestDelegate(PrintOut);
            d.BeginInvoke("Hello", new AsyncCallback(Callback), d);
          
        // Give the callback time to execute - otherwise the app
        // may terminate before it is called
            Thread.Sleep(1000);
            Console.ReadLine();
        }
        static int PrintOut(string parameter)
        {
            Console.WriteLine(parameter);
            return 5;
        }
        static void Callback(IAsyncResult ar)
        {
            TestDelegate d = (TestDelegate)ar.AsyncState;
            Console.WriteLine("Delegate returned {0}", d.EndInvoke(ar));
        }
    }
  
}
