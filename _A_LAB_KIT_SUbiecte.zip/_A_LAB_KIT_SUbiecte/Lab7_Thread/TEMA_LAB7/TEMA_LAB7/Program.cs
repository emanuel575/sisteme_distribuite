﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace TEMA_LAB7
{
    public class Test
    {
        static int[] ar = { 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 };
        static int[] br = new int[10];
        static SumaObject  filelock=new SumaObject (1,2,3,0);
        static int n;
        static int pad,len;
        static void Main()
        {
            n = ar.Length;
            
            SumaObject ob1;
            do
            {
                if (n % 2 == 0)
                { 
                len = n / 2;
                pad = 0;
                }
                else
                {
                    len = n / 2 + 1;
                    pad = 1;
                }
                n = len;
                for (int i = 0; i < len; i++)
                {
                    lock (filelock)
                    {
                        ob1 = new SumaObject(ar[i * 2], ar[i * 2 + 1], i, pad);
                        ThreadPool.QueueUserWorkItem(new WaitCallback(Calcul), ob1);
                    }
                }
                // Give the callback time to execute - otherwise the app
                // may terminate before it is called
                Thread.Sleep(1000);
                for (int i = 0; i < 9; i++)
                    ar[i] = br[i];
                
            }
            while (n > 1);
            
            Console.WriteLine("Rezultat=" + ar[0]);
            
            Console.ReadLine();
        }
        static void Calcul(Object  parameter)
        {
            int suma,i;
            SumaObject x=(SumaObject )parameter;
            lock (filelock)
            {
                if ((x.pad == 1) && (x.i==(len-1)))
                    suma = x.a ;
                else
                    suma = x.a+x.b;
                
                i = x.i;
            
                br[i] = suma;
            }
        }
       
    }
    public class SumaObject
    {
        public int a;
        public int b;
        public int i;
        public int pad;
        public SumaObject (int a1,int b1, int threadnumber,int pad1)
        {
            a = a1;
            b = b1;
            i = threadnumber;
            pad = pad1;
   
        }
       
    }
}
