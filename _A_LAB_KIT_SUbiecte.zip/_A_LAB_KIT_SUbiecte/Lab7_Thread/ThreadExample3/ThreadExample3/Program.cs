﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ThreadExample3
{
    class Program
    {
        static void Main(string[] args)
        {
            string myUrl = "https://docs.microsoft.com/en-us/";
            UrlFetcher fetcher = new UrlFetcher(myUrl);
            new Thread(new ThreadStart(fetcher.Fetch)).Start();
            Console.ReadLine();
        }
    }
    public class UrlFetcher
    {
        string url;
        public UrlFetcher(string url)
        { this.url = url; }
        public void Fetch()
        { // use url here }
            Console.WriteLine(url);
        }
    }
}
