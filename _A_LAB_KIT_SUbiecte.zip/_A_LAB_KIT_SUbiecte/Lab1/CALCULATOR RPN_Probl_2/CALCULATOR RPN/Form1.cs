﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CALCULATOR_RPN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = "";

            this.textBox2.Text = "";
        }

        private static double evalrpn(Stack<string> tks)
        {
            string tk = tks.Pop();
            double x, y;
            if (!Double.TryParse(tk, out x))
            {
                y = evalrpn(tks); x = evalrpn(tks);
                if (tk == "+") x += y;
                else if (tk == "-") x -= y;
                else if (tk == "*") x *= y;
                else if (tk == "/") x /= y;
                else throw new Exception();
            }
            return x;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            char[] sp = new char[] { ' ', '\t' };
            double r;
           
                string s = this.textBox1.Text; //Console.ReadLine();
                if (s == null) r=0 ;
                Stack<string> tks = new Stack<string>(s.Split(sp));
               // if (tks.Count == 0) continue;
                try
                {
                   r = evalrpn(tks);
                    if (tks.Count != 0) throw new Exception();
                    this.textBox2.Text = r.ToString();//Console.WriteLine(r);
                }
                catch (Exception ex) {
                    MessageBox.Show("eroare:"+ex.ToString() );
                }
            


        }
    }
}
