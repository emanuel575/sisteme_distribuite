﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Collections;
using System.Xml;

namespace Lab13_Probl_20
{
    public partial class Form1 : Form
    {
        string[] keyname = {"var1","var2","var3","var4","var5" };
        XmlTextWriter xr;
        float suma ;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Configuration config = ConfigurationManager.OpenExeConfiguration(Application.ExecutablePath);
            suma = 0;
            for (int i=0;i<(keyname.Length -1);i++)
            {
               
                suma += Convert.ToSingle (config.AppSettings.Settings[keyname [i]].Value);
            }
            this.textBox1.Text = suma.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string filename;
            filename = Application.StartupPath + @"\Rezultat.xml";
            xr = new XmlTextWriter(filename, System.Text.Encoding.UTF8);
            xr.Formatting = Formatting.Indented;
            xr.Indentation = 4;
            xr.WriteStartDocument();
                xr.WriteStartElement("suma");
                xr.WriteString(suma.ToString ());
                xr.WriteEndElement();
            xr.Close();

        }
    }
}
