﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Configuration;

namespace Lab13_Tema
{
    class Program
    {
        const string mySection = "mySectionGroup/basics";
       
        static void Main(string[] args)
        {
           
            PluginsList.PluginInfo pla = (PluginsList.PluginInfo)ConfigurationSettings.GetConfig(mySection);
         
            Console.WriteLine("Hello " + pla.AssemblyName + " " + pla.TypeName);
           
            IList<PluginsList.PluginInfo> plc = new PluginsList.PluginInfo[10];
            plc[0] = pla;
            Console.ReadLine();
        }
    }
    public class PluginsList
    {

        public class PluginInfo
        {
            private string assemblyName;
            private string typeName;
            private bool isActive;
            public PluginInfo(string assemblyName, string typeName, bool isActive)
            {
                this.assemblyName = assemblyName;
                this.typeName = typeName;
                this.isActive = isActive;
            }
            public string AssemblyName
            {
                get { return this.assemblyName; }
            }
            public string TypeName
            {
                get { return this.typeName; }
            }
            public bool IsActive
            {
                get { return this.isActive; }

            }
            public override string ToString()
            {
                return String.Format("Assembly name = {0}\nType name = {1}\nIs  active = { 2} ", this.assemblyName, this.typeName, this.isActive);
            }
        }
        private IList<PluginInfo> plugins;
        public IList<PluginInfo> Plugins
        {
            get
            {
                return this.plugins;
            }
            set
            {
                this.plugins = value;
            }
        }
    }

    public class SectionHandler : IConfigurationSectionHandler
    {
        /// <summary>Returns a BasicSettings instance</summary>
        public object Create(object parent, object context, XmlNode section)
        {
            string f = section["assemblyName"].InnerText;
            string l = section["typeName"].InnerText;
            string bx = section["isactive"].InnerText;
            
            return new PluginsList.PluginInfo(f, l, bx=="true");
        }
    }
}
