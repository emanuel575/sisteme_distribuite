﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using MathLibrary;

namespace MathClient
{
    class ClientMain
    {
        static string result;
        static void Main(string[] args)
        {
            RemotingConfiguration.RegisterActivatedClientType(typeof(MathLibrary.Customer), "http://localhost:10000");
            // Calling a nondefault constructor. No exceptions now because
            // Customer is a client-activated object.
            Customer cust = new Customer("Homer");
            result = cust.SayHello();
           Console.WriteLine("Customer Client Result="+result);
            Console.ReadLine();
            Console.ReadLine();
        }
    }


}

