﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting;

namespace MathLibrary
{
    public class SimpleMath : MarshalByRefObject
    {
        public SimpleMath()
        { Console.WriteLine("SimpleMath ctor called"); }
        public int Add(int n1, int n2)
        {
            Console.WriteLine("SimpleMath.Add({0}, {1})", n1, n2);
            return n1 + n2;
        }
        public int Subtract(int n1, int n2)
        {
            Console.WriteLine("SimpleMath.Subtract({0}, {1})", n1, n2);
            return n1 - n2;
        }
    }
    public class Customer : MarshalByRefObject
    {
        string mName;
        public Customer(string name)
        {
            Console.WriteLine("Customer.ctor({0})", name);
            mName = name;
        }
        public string SayHello()
        {
            Console.WriteLine("Customer.SayHello() John");
            return "Hello " + mName;
        }
        public string[] SortVector(string[] str)
        {
            List<string> ls = str.ToList();
            ls.Sort();
            string[] ar = ls.ToArray();
            return  ar;
        }
        public int SearchVector(string[] vec, string searchx)
        {
            int index;
            List<string> ls = vec.ToList();
            index = ls.IndexOf(searchx);
            return index;
        }
        public string[] DeleteString(string[] vec,string element)
        {
            List<string> ls = vec.ToList();
            ls.Remove(element);
            string[] ar = ls.ToArray();
            return ar;
        }
    }
}
