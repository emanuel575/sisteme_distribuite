﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting;

using MathLibrary;

namespace MathClient
{
    class ClientMain
    {
        static void Main(string[] args)
        { // Load the configuration file
            RemotingConfiguration.Configure("MathClient.exe.config");

            Customer math = new Customer("John");
            // Use the remote object
            math.SayHello();
            string[] a1= { "John", "Ana", "Victor", "Luana" };
            Console.WriteLine("Vector Original=" + string.Join(",",a1));
            string[] ar;
             ar=math.SortVector(a1);
            string dog = string.Join(",", ar);
            Console.WriteLine("Rezultat Sortare="+dog);
            int index = math.SearchVector(a1, "Victor");
            Console.WriteLine("Rezultat Cautare  index 'Victor'=" + index);

            ar = math.DeleteString(a1,"Victor");
            dog = string.Join(",", ar);
            Console.WriteLine("Rezultat Stergere 'Victor'=" + dog);

            Console.Write("Press enter to end");
            Console.ReadLine();
        }
    }
}
