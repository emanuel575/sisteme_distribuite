﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Http;
using MathLibrary;

namespace MathClient
{
    class ClientMain
    {
        static void Main(string[] args)
        { // Load the configuration file
            RemotingConfiguration.Configure("MathClient.exe.config");
            // Get a proxy to the remote object
            SimpleMath math = new SimpleMath();
            // Use the remote object
            Console.WriteLine("5 + 2 = {0}", math.Add(5, 2));
            Console.WriteLine("5 - 2 = {0}", math.Subtract(5, 2));
            // Ask user to press Enter
            Console.Write("Press enter to end");
            Console.ReadLine();
        }
    }
}
