using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace SocketServer
{
	/// <summary>
	/// Summary description for SocketServerForm.
	/// </summary>
	public class SocketServerForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button buttonStart;
        private IContainer components;
        private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button cmdReceiveData;
		private System.Windows.Forms.TextBox txtDataRx;
		private System.Windows.Forms.TextBox txtData;
		private System.Windows.Forms.Button cmdSendData;
		private System.Windows.Forms.Button button2;
        private Button button3;
        private Socket m_socListener;
        private static  Socket[] socketarray = new Socket[5];
        private static string receiveText="";
        private Socket client;
        private System.Windows.Forms.Timer timer1;
        private static byte num = 0;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
		static void Main() 
		{
			Application.Run(new SocketServerForm());
		}

		public SocketServerForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(this.m_socListener != null && this.m_socListener.Connected)
			{
				this.m_socListener.Close();
			}

			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.buttonStart = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.cmdReceiveData = new System.Windows.Forms.Button();
            this.txtDataRx = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.cmdSendData = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(8, 8);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(428, 23);
            this.buttonStart.TabIndex = 0;
            this.buttonStart.Text = "Start";
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(8, 48);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Accept Connection";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cmdReceiveData
            // 
            this.cmdReceiveData.Location = new System.Drawing.Point(352, 179);
            this.cmdReceiveData.Name = "cmdReceiveData";
            this.cmdReceiveData.Size = new System.Drawing.Size(84, 56);
            this.cmdReceiveData.TabIndex = 9;
            this.cmdReceiveData.Text = "Receive";
            this.cmdReceiveData.Click += new System.EventHandler(this.cmdReceiveData_Click);
            // 
            // txtDataRx
            // 
            this.txtDataRx.Location = new System.Drawing.Point(8, 179);
            this.txtDataRx.Multiline = true;
            this.txtDataRx.Name = "txtDataRx";
            this.txtDataRx.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDataRx.Size = new System.Drawing.Size(344, 96);
            this.txtDataRx.TabIndex = 8;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(8, 107);
            this.txtData.Multiline = true;
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(344, 56);
            this.txtData.TabIndex = 7;
            this.txtData.Text = "enter data to send here...";
            // 
            // cmdSendData
            // 
            this.cmdSendData.Location = new System.Drawing.Point(352, 107);
            this.cmdSendData.Name = "cmdSendData";
            this.cmdSendData.Size = new System.Drawing.Size(84, 56);
            this.cmdSendData.TabIndex = 6;
            this.cmdSendData.Text = "Send";
            this.cmdSendData.Click += new System.EventHandler(this.cmdSendData_Click);
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button2.Location = new System.Drawing.Point(171, 48);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "Close Connection";
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(340, 47);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(96, 24);
            this.button3.TabIndex = 11;
            this.button3.Text = "Clear Rx Text";
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 200;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // SocketServerForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(473, 287);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cmdReceiveData);
            this.Controls.Add(this.txtDataRx);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.cmdSendData);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonStart);
            this.Name = "SocketServerForm";
            this.Text = "Syncron Server";
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		private void buttonStart_Click(object sender, System.EventArgs e)
		{
			m_socListener = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);		
			IPEndPoint ipLocal = new IPEndPoint ( IPAddress.Any ,8000);
			//bind to local IP Address...
			m_socListener.Bind( ipLocal );
			//start listening...
			m_socListener.Listen (4);
			this.buttonStart.Enabled = false;
            ThreadStart threadsub = new ThreadStart(this.listenClient);
            Thread newThread = new Thread(threadsub);
            newThread.Start();
           

        }
        public  void listenClient()
        {
          while(true)
            {
                socketarray[num] = m_socListener.Accept();

               
                ThreadPool.QueueUserWorkItem(new WaitCallback(ThreadProc), num);
                num++;
               
            }
        
        }
        public static void ThreadProc(Object  numx)
        {
            try
            {
                byte numarThread = (byte)numx;
                byte[] buffer = new byte[1024];
                int iRx;
                while (true)
                {
                    iRx = socketarray[numarThread].Receive(buffer);
                    char[] chars = new char[iRx];
                   
                    System.Text.Decoder d = System.Text.Encoding.UTF8.GetDecoder();

                    int charLen = d.GetChars(buffer, 0, iRx, chars, 0);
                    System.String szData = new System.String(chars);
                  
                    receiveText += szData;
                  
                    if (num > 0)
                        for (Int16 i = 0; i < num; i++)
                      
                    socketarray[i].Send(buffer);
                   
                }
               
            }
            catch (SocketException se)
            {
                MessageBox.Show(se.Message);
            }
        }

        Socket m_commSocket = null;
		

		private void cmdSendData_Click(object sender, System.EventArgs e)
		{
			try
			{
				Object objData = txtData.Text;
				byte[] byData = System.Text.Encoding.ASCII.GetBytes(objData.ToString ());
			
                if (num > 0)
                    for (Int16 i = 0; i < num; i++)
                        socketarray[i].Send(byData);
            }
			catch(SocketException se)
			{
				MessageBox.Show (se.Message );
			}
		}

		private void cmdReceiveData_Click(object sender, System.EventArgs e)
		{
			try
			{
				byte [] buffer = new byte[1024];
                
                int iRx = socketarray [0].Receive(buffer);
                char[] chars = new char[iRx];

				System.Text.Decoder d = System.Text.Encoding.UTF8.GetDecoder();
				int charLen = d.GetChars(buffer, 0, iRx, chars, 0);
				System.String szData = new System.String(chars);
				txtDataRx.Text += szData;
              
                if (num > 0)
                    for (Int16 i = 0; i < num; i++)
                        socketarray[i].Send(buffer);
               
            }
			catch(SocketException se)
			{
				MessageBox.Show (se.Message );
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			if(this.m_commSocket != null && m_commSocket.Connected)
			{
				m_commSocket.Close();
				m_commSocket =null;
			}
		}

        private void button3_Click(object sender, EventArgs e)
        {
            this.txtDataRx.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.txtDataRx.Text = receiveText;
        }

       
    }
    
}
