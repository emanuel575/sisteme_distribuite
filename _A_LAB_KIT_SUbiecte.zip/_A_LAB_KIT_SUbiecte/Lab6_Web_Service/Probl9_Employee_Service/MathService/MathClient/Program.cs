﻿using System;


namespace MathClient
{
    class ClientMain
    {
        static void Main(string[] args)
        {
           
            string str = ""; int i = 0;
            
            ServiceReference1.EmployeeData  empbuf,emplbuf;
            ServiceReference1.EmployeeData[] empleesx;
            //ServiceReference2.SimpleMathSoapClient math = new ServiceReference2.SimpleMathSoapClient();
            //Console.WriteLine("Service Verification");
            //Console.WriteLine("_______________________________________");
            //Console.WriteLine("5 + 3 = {0}", math.Add(5, 3));
            //Console.WriteLine("5 - 3 = {0}", math.Subtract(5, 3));
            ServiceReference1.EmployeeServiceSoapClient emplService = new ServiceReference1.EmployeeServiceSoapClient();
            //empbuf = emplService.GetEmployee(1);
            //empbuf = emplService.GetEmployee(3);
            ServiceReference1.Boss  manager1 = new ServiceReference1.Boss( );
            manager1.Id = 1;
            manager1.Name = "Ioana";
            manager1.SSN = "335";
            manager1.Manager = "Ioana";
            ServiceReference1.Boss manager2 = new ServiceReference1.Boss();
            manager2.Id = 2;
            manager2.Name = "Marius";
            manager2.SSN = "339";
            manager2.Manager = "Marius";
            ServiceReference1.WageEmployee emp1 = new ServiceReference1.WageEmployee();
            emp1.Id = 1;
            emp1.Name = "Irina";
            emp1.SSN = "442";
            emp1.Manager = "Marius";

            ServiceReference1.WageEmployee emp2 = new ServiceReference1.WageEmployee();
            emp2.Id = 2;
            emp2.Name = "Roxana";
            emp2.SSN = "447";
            emp2.Manager = "Marius";

            ServiceReference1.WageEmployee emp3 = new ServiceReference1.WageEmployee();
            emp3.Id = 3;
            emp3.Name = "Claudiu";
            emp3.SSN = "449";
            emp3.Manager = "Ioana";
            emplService.ClearEmpl();
            emplService.ClearManagers();
            
            emplService.AddManager(manager1);
            emplService.AddManager(manager2);

            emplService.AddEmployee(emp1);
            emplService.AddEmployee(emp2);
            emplService.AddEmployee(emp3);
            Console.WriteLine();
            Console.WriteLine("EmployeesService Verification");
            Console.WriteLine("_______________________________________");
            Console.WriteLine("Nr mangers=" + emplService.GetNRManagers()+" Nr Emplpyees="+emplService.GetNREmpl() );
            emplbuf = emp2;
            empbuf = emplService.GetManagerOf(emplbuf);
            Console.WriteLine("Manager of "+emplbuf.Name +" : "+  " " + empbuf.Name );
            str = "";
            empleesx = emplService.GetManagers();
            for (i = 0; i < emplService.GetNRManagers(); i++)
                str += empleesx[i].Name+" ";
            Console.WriteLine("Managers List=" + str);
            str = "";
            empleesx = emplService.GetEmployees();
            for (i = 0; i < emplService.GetNREmpl(); i++)
                str += empleesx[i].Name + " ";
            Console.WriteLine("Employees List=" + str);

          

            
            emplbuf = manager2;
            empleesx = emplService.GetEmployeesOf(emplbuf);
            if (empbuf != null)
            {
                while (empleesx[i] != null)
                {
                    str += " " + empleesx[i++].Name;
                }
            }
            Console.WriteLine(" Employees of " + emplbuf.Name + " : " + str);

           
            Console.ReadLine();
        }
    }
}
