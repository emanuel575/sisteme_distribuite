﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Xml.Serialization;
using System.IO;

namespace MathService
{
    /// <summary>
    /// Summary description for EmployeeService
    /// </summary>

    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    //public class EmployeeService : System.Web.Services.WebService
    //{

    //    [WebMethod]
    //    public string HelloWorld()
    //    {
    //        return "Hello World";
    //    }
    //}
    public class EmployeeService : System.Web.Services.WebService
    {
        public static EmployeeData[] manx=new EmployeeData[100];
        public static EmployeeData[] emplx=new EmployeeData[100];
        public EmployeeData empx;
        public static int nrman=0;
        public static int nremplx = 0;
        [WebMethod]
        public EmployeeData GetEmployee(int Id)
        {
            if (Id <6)
            {
                empx = new Boss(Id, "Nicol", "333-33-3333","Ionescu");
                manx[nrman] = empx;
                nrman++;
                return empx; 
            }
            else
            {
                empx= new WageEmployee(Id, "Kidman", "444-44-4444","Ionescu");
                emplx[nremplx] = empx;
                nremplx++;
                return empx;
            }
        }
        [WebMethod]
        public EmployeeData GetManager(int Id)
        {
            return manx[Id];
        }
        [WebMethod]
        public int  GetNRManagers()
        {
            return nrman;
        }
        [WebMethod]
        public int GetNREmpl()
        {
            return nremplx;
        }

        [WebMethod]
        public EmployeeData[] GetEmployees()
        {
            
            return emplx;
        }
        [WebMethod]
        public EmployeeData[] GetManagers()
        {

            return manx;
        }

        [WebMethod]
        public void AddManager(EmployeeData e)
        {
            manx[nrman] = e;
            nrman++;
        }
        [WebMethod]
        public void  AddEmployee( EmployeeData e)
        {
            emplx[nremplx] = e;
            nremplx++;
        }
        [WebMethod]
        public void ClearManagers()
        {
            nrman = 0;
        }
        [WebMethod]
        public void ClearEmpl()
        {
            nremplx = 0;
        }
        [WebMethod]
        public EmployeeData GetManagerOf(EmployeeData e)
        {
            int i,index;
            index = -1;
            for (i = 0; i < nrman; i++)
                if (manx[i].Manager  == e.Manager)
                    index = i;
            if (index >= 0)
                return manx[index];
            else
                return null;
        }
        [WebMethod]
        public EmployeeData[]  GetEmployeesOf(EmployeeData e)
        {
            EmployeeData[] emplees = new EmployeeData[100];
            int i, index;
            index = 0;
            for (i = 0; i < nremplx; i++)
                if (emplx[i].Manager == e.Name)
                    emplees[index++] = emplx[i];
            return emplees;
        }
     
    }
    
    [XmlInclude(typeof(WageEmployee)), XmlInclude(typeof(Boss))]
    public abstract class EmployeeData
    {
        public string Name;
        public string SSN;
        [XmlAttribute()]
        public int Id;
        public string Manager;
        
        public EmployeeData(int id, string name, string ssn,string mng)
        { Id = id; Name = name; SSN = ssn; Manager = mng; }
        public override string ToString()
        { return string.Format("ID={0};Name={1};SSN={2};Mng={3}", Id, Name, SSN,Manager); }
        public abstract double ComputePay();
        //Required by XmlSerializer
        public EmployeeData() { }
    }
    public class WageEmployee : EmployeeData
    {
        public double Wage;
        public double Hours;
        public override double ComputePay()
        { return Wage * Hours; }
        internal WageEmployee(int id, string name, string ssn,string managername) : base(id, name, ssn,managername)
        { Wage = 10; Hours = 40; }
        public WageEmployee() { }
    }
    public class Boss : EmployeeData
    {
        public double Salary;
        public override double ComputePay()
        { return Salary; }
        internal Boss(int id, string name, string ssn, string mng) : base(id, name, ssn,mng) { Salary = 9999; }
        public Boss() { }
    }
}
