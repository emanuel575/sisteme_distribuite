﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace GetSystemTime_Proj
{
    public  struct SYSTEMTIMEX
    {
        public short wYear;
        public short wMonth;
        public short wDayOfWeek;
        public short wDay;
        public short wHour;
        public short wMinute;
        public short wSecond;
        public short wMilliseconds;
    }
    public partial class Form1 : Form
      
    {

        // void GetSystemTime(LPSYSTEMTIME lpSystemTime)
        //typedef struct _SYSTEMTIME
        //{
        //    WORD wYear;
        //    WORD wMonth;
        //    WORD wDayOfWeek;
        //    WORD wDay;
        //    WORD wHour;
        //    WORD wMinute;
        //    WORD wSecond;
        //    WORD wMilliseconds;
        //}

        public SYSTEMTIMEX tc,ts;
        [DllImport("kernel32.dll")]
        public static extern void GetLocalTime(ref SYSTEMTIMEX tx);

        [DllImport("kernel32.dll")]
        public static extern void GetSystemTime(ref SYSTEMTIMEX tx);
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            GetLocalTime(ref tc);
            GetSystemTime(ref ts);
            this.textBox1.Text = tc.wHour.ToString()+":"+tc.wMinute .ToString()+":"+tc.wSecond.ToString ();
            this.textBox2.Text = ts.wHour.ToString() + ":" + ts.wMinute.ToString() + ":" + ts.wSecond.ToString();
        }
    }
}
