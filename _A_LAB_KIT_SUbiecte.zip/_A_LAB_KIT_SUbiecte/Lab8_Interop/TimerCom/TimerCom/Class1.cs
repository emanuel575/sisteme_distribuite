﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;   //  Defines ClassInterfaceAttribute
using System.ComponentModel;

namespace TimerCom
{
    [Guid("A5F0C24B-3047-4786-B7E1-690A95CE6E49"), Description("ElementInfo class interface")]
    public interface ITimer
    {
        /// <remarks>
        /// DispId(0) is default COM property
        /// </remarks>
        [DispId(0), Description("To String Function")]
        String ToString { get; }
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>   Gets or sets the element ID </summary>
        /// <remarks>DLong is a data type that stores a 64-bit integer in two 32-bit words</remarks>
        [DispId(1), Description("Timpul Curent")]
         String ServerTimer();
       
    }
    [Guid("2E1F9965-AB79-4EE3-B677-CC94221F2166"), Description("ElementInfo class")]
    [ComVisible(true), ClassInterface(ClassInterfaceType.None)]
    public class TimerObject : ITimer
    {
        public TimerObject()
        {

        }
        [ComVisible(true), Description("Description of this Element")]
        public  new String ToString
        {
            get
            {
                StringBuilder s = new StringBuilder();
                s.AppendFormat("TimerComponent");
                return s.ToString();
            }
        }
        [ComVisible(true), Description("Description of this Element")]
        public String ServerTimer()
        {
            return DateTime.Now.ToString("h:mm:ss tt");
        }


    }


}
