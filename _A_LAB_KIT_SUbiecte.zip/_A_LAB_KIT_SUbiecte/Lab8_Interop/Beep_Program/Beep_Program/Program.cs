﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace Beep_Program
{
    class Program
    {
        [DllImport("kernel32.dll")]
        public static extern bool Beep(int frequency, int duration);
        static void Main(string[] args)
        {
            Random random = new Random();
            for (int i = 0; i < 10000; i++)
            { Beep(random.Next(10000), 100); }
        }
    }
}
